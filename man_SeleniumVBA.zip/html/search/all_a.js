var searchData=
[
  ['maximizewindow_0',['MaximizeWindow',['../class_web_driver.html#a1285ea107daf5b1abbf9cf32b42fe7e9',1,'WebDriver']]],
  ['minimizewindow_1',['MinimizeWindow',['../class_web_driver.html#aee5a1541204698bbd7276c9effc4032e',1,'WebDriver']]]
];

var searchData=
[
  ['refresh_0',['Refresh',['../class_web_driver.html#a9c17cf7da77de0f461861569d5450610',1,'WebDriver']]],
  ['remove_1',['Remove',['../class_web_elements.html#a9be43b8e61f037ee819b50483b72ba9c',1,'WebElements']]]
];

var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstwx",
  1: "w",
  2: "w",
  3: "acdefghimnoprsw",
  4: "bs",
  5: "cilnpstx",
  6: "r",
  7: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "全て",
  1: "クラス",
  2: "ファイル",
  3: "関数",
  4: "列挙型",
  5: "列挙値",
  6: "フレンド",
  7: "ページ"
};

